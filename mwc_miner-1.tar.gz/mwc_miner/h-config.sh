#!/usr/bin/env bash

# h-config.sh — generates mwc_miner.conf from HiveOS flight sheet
# $CUSTOM_USER_CONFIG = contents of "Extra config" field in flight sheet

mkdir -p /var/log/miner/mwc_miner

# Defaults
BATCH_SIZE="3000000"
INSTANCES="1"
OFFSET="0"
RESUME=""
ADDRESSES=""

# Parse KEY=VALUE lines from flight sheet extra config
# Uses printf | while read — works in both bash and sh (no <<< herestring)
if [ -n "$CUSTOM_USER_CONFIG" ]; then
    printf '%s\n' "$CUSTOM_USER_CONFIG" | while IFS='=' read -r key val; do
        key=$(printf '%s' "$key" | tr -d ' \r')
        val=$(printf '%s' "$val" | tr -d '\r')
        case "$key" in
            batch-size|BATCH_SIZE) BATCH_SIZE="$val" ;;
            instances|INSTANCES)   INSTANCES="$val" ;;
            offset|OFFSET)         OFFSET="$val" ;;
            resume|RESUME)         RESUME="$val" ;;
            ADDRESSES)             ADDRESSES="$val" ;;
        esac
    done
fi

# Write config file that h-run.sh will source
cat > "$CUSTOM_CONFIG_FILENAME" << EOF
BATCH_SIZE=$BATCH_SIZE
INSTANCES=$INSTANCES
OFFSET=$OFFSET
RESUME=$RESUME
ADDRESSES=$ADDRESSES
EOF

echo "mwc_miner config: batch=$BATCH_SIZE instances=$INSTANCES offset=$OFFSET"
