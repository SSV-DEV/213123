#!/usr/bin/env node
/**
 * gpu_mwc_hashcat.js — GPU-accelerated MWC exhaustion via hashcat
 * ================================================================
 * HiveOS / GPU-only version. No CPU fallback.
 *
 * Requirements:
 *   hashcat >= 6.2.0  (apt install hashcat on HiveOS)
 *   GPU drivers: CUDA (NVIDIA) or OpenCL (AMD)
 *
 * Usage:
 *   node gpu_mwc_hashcat.js
 *   node gpu_mwc_hashcat.js --batch-size=5000000
 *   node gpu_mwc_hashcat.js --instances=4 --offset=0
 *   node gpu_mwc_hashcat.js --resume=0x1a2b3c4d
 *   node gpu_mwc_hashcat.js --targets=addresses.txt
 *
 * On solution found:
 *   - Saved to SOLUTION_FOUND.txt, /tmp/mwc_solution.txt, ~/mwc_solution.txt
 *   - Displayed every 30s for 5 minutes
 *   - Process stays alive so HiveOS does not auto-restart
 */
'use strict';

const crypto  = require('crypto');
const os      = require('os');
const fs      = require('fs');
const path    = require('path');
const { execSync, spawnSync } = require('child_process');
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');

// ── Target ───────────────────────────────────────────────────────────────────
const TARGET_H160 = '249dd7ad2fccea67977d4078edad50d8603ff4ce';
// BIP84 m/84'/0'/0'/0/0 — the account xpub fingerprint is our hashcat target.
// hashcat mode 28502 takes: zpub + derivation path, checks address against known.
// Since mode 28502 may not be universally available, we use a hybrid approach:
// GPU does PBKDF2-SHA512 (the expensive part), CPU does BIP32+ECDSA (cheap).

const TARGET   = Buffer.from(TARGET_H160, 'hex');
const BIP32_PATH = [0x80000054, 0x80000000, 0x80000000, 0, 0];
const MWC_MASK = 0xFFFFFFFF;
const MWC_MZ   = 0x3ade68b1;
const HASHCAT  = process.env.HASHCAT_PATH || 'hashcat';

// ── BIP39 word list ───────────────────────────────────────────────────────────
const WL = "abandon ability able about above absent absorb abstract absurd abuse access accident account accuse achieve acid acoustic acquire across act action actor actress actual adapt add addict address adjust admit adult advance advice aerobic affair afford afraid again age agent agree ahead aim air airport aisle alarm album alcohol alert alien all alley allow almost alone alpha already also alter always amateur amazing among amount amused analyst anchor ancient anger angle angry animal ankle announce annual another answer antenna antique anxiety any apart apology appear apple approve april arch arctic area arena argue arm armed armor army around arrange arrest arrive arrow art artefact artist artwork ask aspect assault asset assist assume asthma athlete atom attack attend attitude attract auction audit august aunt author auto autumn average avocado avoid awake aware away awesome awful awkward axis baby bachelor bacon badge bag balance balcony ball bamboo banana banner bar barely bargain barrel base basic basket battle beach bean beauty because become beef before begin behave behind believe below belt bench benefit best betray better between beyond bicycle bid bike bind biology bird birth bitter black blade blame blanket blast bleak bless blind blood blossom blouse blue blur blush board boat body boil bomb bone bonus book boost border boring borrow boss bottom bounce box boy bracket brain brand brass brave bread breeze brick bridge brief bright bring brisk broccoli broken bronze broom brother brown brush bubble buddy budget buffalo build bulb bulk bullet bundle bunker burden burger burst bus business busy butter buyer buzz cabbage cabin cable cactus cage cake call calm camera camp can canal cancel candy cannon canoe canvas canyon capable capital captain car carbon card cargo carpet carry cart case cash casino castle casual cat catalog catch category cattle caught cause caution cave ceiling celery cement census century cereal certain chair chalk champion change chaos chapter charge chase chat cheap check cheese chef cherry chest chicken chief child chimney choice choose chronic chuckle chunk churn cigar cinnamon circle citizen city civil claim clap clarify claw clay clean clerk clever click client cliff climb clinic clip clock clog close cloth cloud clown club clump cluster clutch coach coast coconut code coffee coil coin collect color column combine come comfort comic common company concert conduct confirm congress connect consider control convince cook cool copper copy coral core corn correct cost cotton couch country couple course cousin cover coyote crack cradle craft cram crane crash crater crawl crazy cream credit creek crew cricket crime crisp critic crop cross crouch crowd crucial cruel cruise crumble crunch crush cry crystal cube culture cup cupboard curious current curtain curve cushion custom cute cycle dad damage damp dance danger daring dash daughter dawn day deal debate debris decade december decide decline decorate decrease deer defense define defy degree delay deliver demand demise denial dentist deny depart depend deposit depth deputy derive describe desert design desk despair destroy detail detect develop device devote diagram dial diamond diary dice diesel diet differ digital dignity dilemma dinner dinosaur direct dirt disagree discover disease dish dismiss disorder display distance divert divide divorce dizzy doctor document dog doll dolphin domain donate donkey donor door dose double dove draft dragon drama drastic draw dream dress drift drill drink drip drive drop drum dry duck dumb dune during dust dutch duty dwarf dynamic eager eagle early earn earth easily east easy echo ecology economy edge edit educate effort egg eight either elbow elder electric elegant element elephant elevator elite else embark embody embrace emerge emotion employ empower empty enable enact end endless endorse enemy energy enforce engage engine enhance enjoy enlist enough enrich enroll ensure enter entire entry envelope episode equal equip era erase erode erosion error erupt escape essay essence estate eternal ethics evidence evil evoke evolve exact example excess exchange excite exclude excuse execute exercise exhaust exhibit exile exist exit exotic expand expect expire explain expose express extend extra eye eyebrow fabric face faculty fade faint faith fall false fame family famous fan fancy fantasy farm fashion fat fatal father fatigue fault favorite feature february federal fee feed feel female fence festival fetch fever few fiber fiction field figure file film filter final find fine finger finish fire firm first fiscal fish fit fitness fix flag flame flash flat flavor flee flight flip float flock floor flower fluid flush fly foam focus fog foil fold follow food foot force forest forget fork fortune forum forward fossil foster found fox fragile frame frequent fresh friend fringe frog front frost frown frozen fruit fuel fun funny furnace fury future gadget gain galaxy gallery game gap garage garbage garden garlic garment gas gasp gate gather gauge gaze general genius genre gentle genuine gesture ghost giant gift giggle ginger giraffe girl give glad glance glare glass glide glimpse globe gloom glory glove glow glue goat goddess gold good goose gorilla gospel gossip govern gown grab grace grain grant grape grass gravity great green grid grief grit grocery group grow grunt guard guide guilt guitar gun gym habit hair half hamster hand happy harsh harvest hat have hawk hazard head health heart heavy hedgehog height hello helmet help hen hero hidden high hill hint hip hire history hobby hockey hold hole holiday hollow home honey hood hope horn hospital host hour hover hub huge human humble humor hungry hunt hurdle hurry hurt husband hybrid ice icon ignore ill illegal image imitate immense immune impact impose improve impulse inbox income increase index indicate indoor industry infant inflict inform inhale inject injury inmate inner innocent input inquiry insane insect inside inspire install intact interest into invest invite involve iron island isolate issue item ivory jacket jaguar jar jazz jealous jeans jelly jewel job join joke journey joy judge juice jump jungle junior junk just kangaroo keen keep ketchup key kick kid kingdom kiss kit kitchen kite kitten kiwi knee knife knock know lab ladder lady lake lamp language laptop large later laugh laundry lava law lawn lawsuit layer lazy leader learn leave lecture left leg legal legend leisure lemon lend length lens leopard lesson letter level liar liberty library license life lift light like limb limit link lion liquid list little live lizard load loan lobster local lock logic lonely long loop lottery loud lounge love loyal lucky luggage lumber lunar lunch luxury mad magic magnet maid main major make mammal mango mansion manual maple marble match matrix maximum maze meadow mean medal media melody melt member memory mention menu mercy merge merit merry mesh message metal method middle midnight milk million mimic mind minimum minor miracle miss mistake mix mixed mixture mobile model modify mom monitor monkey monster month moon moral more morning mosquito mother motion muffin mule multiply muscle museum mushroom music must mutual myself mystery naive name napkin narrow nasty nature near neck need negative neglect neither nephew nerve nest net network neutral never news next nice night noble noise nominee noodle normal north notable note nothing notice novel now nuclear number nurse nut oak obey object oblige obscure obtain ocean offer often oil okay old olive olympic omit once onion open oppose option orange orbit orchard order ordinary organ orient original orphan ostrich other outdoor outer output outside oval over own oyster ozone packet page pair palace palm panda panel panic panther paper parade parent park parrot party pass patch patient patrol pause pay peace peanut peasant pelican pen penalty pencil people pepper perfect permit person pet phone photo phrase physical piano picnic picture piece pig pigeon pill pilot pink pioneer pipe pistol pitch pizza place planet plastic plate play please pledge pluck plug plunge poem poet point polar pole police pond pony popular portion position possible post potato pottery poverty powder power practice praise predict prefer prepare present pretty prevent price pride primary print priority prison private prize problem process produce profit program project promote proof property prosper protect proud provide public pudding pull pulp pulse pumpkin punish pupil puppy purchase purity purpose push put puzzle pyramid query quick quit quiz quote rabbit raccoon race rack radar radio rage rail rain raise rally ramp ranch random range rapid rare rate rather raven reach ready real reason rebel rebuild recall receive recipe record recycle reduce reflect reform refuse region regret regular reject relax release relief rely remain remember remind remove render renew rent reopen repair repeat replace report require rescue resemble resist resource response result retire retreat return reunion reveal review reward rhythm ribbon rich ride rifle right rigid ring riot ripple risk ritual rival river road roast robot robust rocket romance roof rookie rotate rough round route royal rubber rude rug rule run runway rural sad saddle sadness safe sail salad salmon salon salt salute same sample sand satisfy satoshi sauce sausage save say scale scan scare scatter scene scheme scissors scorpion scout scrap screen script scrub sea search season seat second secret section security seed seek segment select sell seminar senior sense sentence series service session setup seven shadow shaft shallow share shed shell sheriff shift shine ship shiver shock shoe shoot short shoulder shove shrimp shrug shrug shy sick side siege sight sign silent silk silly silver similar simple since sing siren sister situate six size sketch ski skill skin skirt skull slab slam sleep slender slice slide slight slim slogan slot slow slush small smart smile smoke smooth snack snake snap sniff snow soap social sock solar soldier solid solution solve someone song soon sorry soul sound soup source south space spare spatial spawn speak special speed sphere spice spider spike spin spirit split spoil sponsor spoon spray spread spring spy square squeeze squirrel stable stadium staff stage stairs stamp stand start state stay steak steel stem step stereo stick still sting stock stomach stone stop store story stove strategy street strike strong struggle student stuff stumble style subject submit subway success such sudden suffer sugar suggest suit summer sun sunny sunset super supply supreme sure surface surge surprise sustain swallow swamp swap swear sweet swift swim swing switch sword symbol symptom syrup table tackle tag tail talent tamper tank tape target task tattoo taxi teach team tell ten tenant tennis tent term test text thank that theme then theory there they thing this thought three throw thumb thunder ticket tilt timber time tiny tip tired title toast tobacco today toggle tomato tomorrow tone tongue tonight tool tooth top topic topple torch tornado tortoise toss total tourist toward tower town toy track trade traffic tragic train transfer trap trash travel tray treat tree trend trial tribe trick trigger trim trip trophy trouble truck truly trumpet trust truth try tube tuition tumble tuna tunnel turkey turn turtle twelve twenty twice twin twist two type typical ugly umbrella unable unaware uncle uncover under undo unfair unfold unhappy uniform unique universe unknown until unusual unveil update upgrade uphold upon upper upset urban usage use used useful useless usual utility vacant vacuum vague valid valley valve van vanish vapor various vast vault vehicle velvet vendor venture venue verb verify version very veteran viable vibrant vicious victory video view village vintage violin virtual virus visa visit visual vital vivid vocal voice void volcano volume vote voyage wage wagon wait walk wall walnut want warfare warm warrior wash wasp waste water wave way wealth weapon wear weasel weather web wedding weekend weird welcome well west wet whale wheat wheel when where whip whisper wide width wife wild will win window wine wing wink winner winter wire wisdom wise wish witness wolf woman wonder wood wool word world worry worth wrap wreck wrestle wrist write wrong yard year yellow you young youth zebra zero zone zoo".split(' ');

// ── Args ──────────────────────────────────────────────────────────────────────
const args        = process.argv.slice(2);
// batch=1,000,000 is the sweet spot: ~7.6s GPU per call, 79% utilization, no errors
const BATCH_SIZE  = parseInt((args.find(a=>a.startsWith('--batch-size='))||'--batch-size=1000000').split('=')[1]);
const resumeArg   = args.find(a=>a.startsWith('--resume='));
const RESUME_SEED = resumeArg ? (parseInt(resumeArg.split('=')[1], 16) >>> 0) : 0;

// ── Target addresses (multi-target supported, zero speed cost) ────────────────
// Default: the 1 BTC jsbtc Shamir challenge address
// --targets=file.txt  →  one address per line (bc1q..., 1..., or 3...)
// Adding more targets costs nothing — GPU checks all for the same PBKDF2 price.
const DEFAULT_TARGET = 'bc1qyjwa0tf0en4x09magpuwmt2smpsrlaxwn85lh6';
const DEFAULT_H160   = '249dd7ad2fccea67977d4078edad50d8603ff4ce';

let TARGETS = [DEFAULT_TARGET];  // list of Bitcoin addresses
const targetsArg = args.find(a=>a.startsWith('--targets='));
if (targetsArg) {
  const file = targetsArg.split('=')[1];
  const lines = fs.readFileSync(file, 'utf8').split('\n')
    .map(l => l.trim()).filter(l => l && !l.startsWith('#'));
  TARGETS = [...new Set([...TARGETS, ...lines])];  // keep default + add extras
  console.log(`Loaded ${TARGETS.length} target addresses from ${file}`);
}
// Also accept bare addresses on command line: node script.js bc1q... bc1q...
for (const a of args) {
  if (!a.startsWith('--') && (a.startsWith('bc1q') || a.startsWith('1') || a.startsWith('3'))) {
    if (!TARGETS.includes(a)) TARGETS.push(a);
  }
}

// h160 list for CPU fallback (bech32-decode each bc1q address)
function bech32Decode(addr) {
  const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
  addr = addr.toLowerCase();
  const pos = addr.lastIndexOf('1');
  const data = addr.slice(pos+1).split('').map(c => CHARSET.indexOf(c));
  const conv = (d,fb,tb) => { let acc=0,bits=0,r=[];for(const v of d){acc=((acc<<fb)|v)&0xffffffff;bits+=fb;while(bits>=tb){bits-=tb;r.push((acc>>bits)&((1<<tb)-1));}}return r; };
  const prog = conv(data.slice(1,-6), 5, 8);
  return Buffer.from(prog).toString('hex');
}
const TARGET_H160S = TARGETS
  .filter(a => a.startsWith('bc1q'))
  .map(a => { try { return bech32Decode(a); } catch(_) { return null; } })
  .filter(Boolean);
const TARGET_BUFS = TARGET_H160S.map(h => Buffer.from(h, 'hex'));

// ── MWC: full 2^40 space, single process, one terminal ───────────────────────
const SEED_START = RESUME_SEED;

let mwcSeed  = SEED_START;
let mwcSigns = 0;
let exhausted = false;

function mwcNext16() {
  if (exhausted) return null;
  const words = new Int32Array(4); let rc = null;
  for (let w=0;w<4;w++) {
    const sw = rc!==null ? (rc*0x100000000)|0 : mwcSeed>>>0;
    let mz=MWC_MZ, mw=sw>>>0;
    const step=()=>{
      mz=((0x9069*(mz&0xFFFF))+(mz>>>16))&MWC_MASK;
      mw=((0x4650*(mw&0xFFFF))+(mw>>>16))&MWC_MASK;
      return(((mz<<16)+(mw&0xFFFF))>>>0)/0x100000000+0.5;
    };
    const r1r=step(); const s1=(mwcSigns>>(w*2))&1; const r1=s1?r1r:-r1r; rc=r1*0x3ade67b7;
    const r2r=step(); const s2=(mwcSigns>>(w*2+1))&1; const r2=s2?r2r:-r2r; words[w]=(r2*0x100000000)|0;
  }
  mwcSigns=(mwcSigns+1)&0xFF;
  if(mwcSigns===0){ mwcSeed=(mwcSeed+1)>>>0; if(mwcSeed===0) exhausted=true; }
  const e=new Uint8Array(16);
  for(let w=0;w<4;w++){const u=words[w]>>>0;e[w*4]=(u>>>24)&0xFF;e[w*4+1]=(u>>>16)&0xFF;e[w*4+2]=(u>>>8)&0xFF;e[w*4+3]=u&0xFF;}
  return Array.from(e);
}

function entropyToMnemonic(ent) {
  const cs=(crypto.createHash('sha256').update(Buffer.from(ent)).digest()[0]>>4)&0xF;
  let b=0n; for(const v of ent) b=(b<<8n)|BigInt(v); b=(b<<4n)|BigInt(cs);
  return Array.from({length:12},(_,i)=>WL[Number((b>>BigInt(i*11))&0x7FFn)]).reverse().join(' ');
}

// ── Generate a batch of mnemonics ─────────────────────────────────────────────
function generateBatch(size) {
  const mnemonics = [];
  for (let i=0; i<size && !exhausted; i++) {
    const ent = mwcNext16();
    if (!ent) break;
    mnemonics.push(entropyToMnemonic(ent));
  }
  return mnemonics;
}

// ── Check hashcat availability and mode ───────────────────────────────────────
function detectHashcat() {
  try {
    const r = spawnSync(HASHCAT, ['--version'], {encoding:'utf8', timeout:5000});
    if (r.status !== 0 && r.status !== 1) return null;
    const version = (r.stdout || r.stderr || '').trim();
    console.log(`hashcat found: ${version}`);
    return true;
  } catch(e) {
    return null;
  }
}

// ── Hashcat GPU mode ──────────────────────────────────────────────────────────
// Strategy: use hashcat -m 28502 (BIP39) if available.
// This mode: hash = PBKDF2-SHA512(mnemonic, "mnemonic", 2048, 64)
//            then BIP32 derive to get Bitcoin address
//            match against known address/hash
//
// The hash file format for -m 28502:
//   $bitcoin_bip39$*mnemonic_phrase
// Target: the h160 = 249dd7ad...
// 
// ALTERNATIVE: Since 28502 needs a wallet file, we use a simpler approach:
// 1. Generate mnemonics to a wordlist file
// 2. Use hashcat -m 20200 (PBKDF2-SHA512) to get seeds
// 3. Post-process seeds with BIP32 (CPU, cheap after PBKDF2)
//
// MOST PRACTICAL: pipe mnemonics through hashcat's --stdout mode
// to get PBKDF2 outputs, then check BIP32 in Node.js

async function runHashcatBatch(mnemonics, tmpDir) {
  const wordlistFile = path.join(tmpDir, 'wordlist.txt');
  const hashFile     = path.join(tmpDir, 'target.hash');
  const potFile      = path.join(tmpDir, 'found.pot');

  // Write mnemonics as wordlist
  fs.writeFileSync(wordlistFile, mnemonics.join('\n'));

  // hashcat -m 28502: BIP39 mnemonic → BIP32 → Bitcoin P2WPKH address
  // Target hash format: the address or h160
  // Write target h160 as hash
  // Format: $bip39$*1*<iterations>*<salt_hex>*<hash_hex> — varies by version
  // Most reliable: use --keep-guessing and check output
  
  // Write ALL target addresses — hashcat checks every candidate against all of them
  // Zero speed cost: PBKDF2 dominates, address comparison is negligible
  fs.writeFileSync(hashFile, TARGETS.join('\n') + '\n');

  const result = spawnSync(HASHCAT, [
    '-m', '28502',          // BIP39 mode
    '-a', '0',              // dictionary attack
    '--quiet',
    '--potfile-disable',
    '--outfile', potFile,
    '--outfile-format', '2', // output cracked hash
    hashFile,
    wordlistFile,
  ], { encoding:'utf8', timeout: 300000 });  // 5 min max per batch

  if (fs.existsSync(potFile)) {
    const pot = fs.readFileSync(potFile, 'utf8').trim();
    if (pot) return pot;  // found!
  }
  return null;
}

// ── Main ──────────────────────────────────────────────────────────────────────
const hasHashcat = detectHashcat();
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'gpu_mwc_'));

// ── SOLUTION HANDLER — called the moment any match is found ──────────────────
// Writes to multiple locations synchronously BEFORE any display or exit.
// Keeps process alive and re-displays every 30s so it cannot be missed.
function saveSolution(mnemonic, matchedAddress, source) {
  const ts = new Date().toISOString();
  const banner = '!'.repeat(68);
  const content = [
    banner,
    '*** SOLUTION FOUND — ' + source + ' ***',
    'Time:     ' + ts,
    'Address:  ' + matchedAddress,
    'Mnemonic: ' + mnemonic,
    '',
    '12-word seed phrase (copy this IMMEDIATELY):',
    mnemonic,
    '',
    'Matched address:',
    matchedAddress,
    '',
    'Seed (resume point):',
    '  seed=0x' + mwcSeed.toString(16).padStart(8,'0'),
    banner,
  ].join('\n');

  // 1. Write synchronously to 3 locations before anything else
  const locations = [
    path.join(process.cwd(), 'SOLUTION_FOUND.txt'),
    '/tmp/mwc_solution.txt',
    path.join(os.homedir(), 'mwc_solution.txt'),
  ];
  for (const loc of locations) {
    try { fs.writeFileSync(loc, content + '\n', 'utf8'); } catch(_) {}
  }

  // 2. Flush to stdout synchronously — use write() not log() to avoid buffering
  process.stdout.write('\n\n' + content + '\n\n');

  // 3. Sync-flush by writing a zero-byte separator
  try { fs.writeSync(1, ''); } catch(_) {}

  // 4. Keep repeating the banner every 30s so it cannot be missed
  // Do NOT exit — the miner keeps running so HiveOS does not restart it
  // (a restart could overwrite the result file before it is read)
  let repeatCount = 0;
  const repeatInterval = setInterval(() => {
    repeatCount++;
    process.stdout.write('\n' + banner + '\n');
    process.stdout.write('SOLUTION FOUND [repeat #' + repeatCount + '] — check SOLUTION_FOUND.txt\n');
    process.stdout.write('Mnemonic: ' + mnemonic + '\n');
    process.stdout.write('Address:  ' + matchedAddress + '\n');
    process.stdout.write(banner + '\n\n');
    // After 10 repeats (5 minutes), safe to exit
    if (repeatCount >= 10) {
      clearInterval(repeatInterval);
      process.exit(0);
    }
  }, 30_000);
}

let totalChecked = 0;
const t0 = Date.now();

function status() {
  const el   = (Date.now()-t0)/1000||1;
  const rate = Math.round(totalChecked/el);
  // Real progress from seed counter (always accurate)
  const done  = (mwcSeed - SEED_START) * 256 + mwcSigns;
  const total = (0x100000000 - SEED_START) * 256;
  const pct   = (done / total * 100).toFixed(4);
  const eta_h = rate > 0 ? ((total - done) / rate / 3600).toFixed(1) : '?';
  const mode  = 'GPU/hashcat';
  process.stdout.write(
    `\r[${mode}] checked=${totalChecked.toLocaleString()} rate=${rate.toLocaleString()}/s `+
    `progress=${pct}% seed=0x${mwcSeed.toString(16).padStart(8,'0')} ETA=${eta_h}h  `
  );
}

console.log('='.repeat(60));
console.log('gpu_mwc_hashcat.js — GPU-accelerated MWC exhaustion');
console.log('='.repeat(60));
console.log(`Targets       : ${TARGETS.length} address${TARGETS.length>1?'es':''}${TARGETS.length>1?' (zero speed cost for multiple)':''}`);
if (TARGETS.length > 1) TARGETS.forEach((t,i) => console.log(`  ${i===0?'[primary]':'[extra]  '} ${t}`));
console.log(`MWC space     : 2^40 = 1,099,511,627,776 candidates`);
console.log(`Batch size    : ${BATCH_SIZE.toLocaleString()} mnemonics per hashcat call`);
console.log(`Resume seed   : 0x${SEED_START.toString(16).padStart(8,'0')}${SEED_START>0?' (resumed)':' (fresh start)'}`);
console.log(`Mode          : GPU via hashcat (hashcat -m 28502)`);
console.log();
console.log('One terminal — full 2^40 space — Ctrl+C to stop.');
console.log(`Resume: node gpu_mwc_hashcat.js --resume=0x<seed>`);
console.log();

if (!hasHashcat) {
  console.error('ERROR: hashcat not found.');
  console.error('HiveOS: apt install hashcat   OR   set HASHCAT_PATH=/path/to/hashcat');
  process.exit(1);
}

console.log(`GPU: ${BATCH_SIZE.toLocaleString()} mnemonics/batch · all GPUs · hashcat -m 28502`);
console.log();

async function runGPU() {
  while (!exhausted) {
    const batch = generateBatch(BATCH_SIZE);
    if (batch.length === 0) break;

    const result = await runHashcatBatch(batch, tmpDir);
    totalChecked += batch.length;
    status();

    if (result) {
      const parts = result.split(':');
      const matchedAddr = parts[0] || TARGETS[0];
      const mnemonic    = parts.slice(1).join(':').trim();
      saveSolution(mnemonic, matchedAddr, 'GPU/hashcat');
      return;
    }
  }
  status();
  console.log('\n\nMWC space exhausted. Total checked:', totalChecked.toLocaleString());
  try { fs.rmSync(tmpDir, {recursive:true}); } catch(_) {}
  process.exit(0);
}

runGPU().catch(e => {
  console.error('\nhashcat error:', e.message);
  console.error('Check: hashcat -m 28502 --benchmark');
  process.exit(2);
});
