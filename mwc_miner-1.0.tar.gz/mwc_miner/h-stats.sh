#!/usr/bin/env bash

# h-stats.sh — parses mwc_miner output and reports to HiveOS dashboard
# Must set $khs (total hashrate in kH/s) and $stats (JSON)

LOG="/var/log/miner/mwc_miner/mwc_miner.log"

# Parse the most recent status line from the log
# Format: [GPU/hashcat] checked=N rate=R/s progress=P% seed=0xS ETA=Hh
LAST=$(grep -o '\[GPU/hashcat\].*' "$LOG" 2>/dev/null | tail -1)
[[ -z "$LAST" ]] && LAST=$(grep -o '\[CPU/threads\].*' "$LOG" 2>/dev/null | tail -1)

RATE=0
PROGRESS=0
SEED="0x00000000"
ETA="?"

if [[ -n "$LAST" ]]; then
    RATE=$(echo "$LAST" | grep -oP 'rate=\K[0-9]+')
    PROGRESS=$(echo "$LAST" | grep -oP 'progress=\K[0-9.]+')
    SEED=$(echo "$LAST" | grep -oP 'seed=\K0x[0-9a-f]+')
    ETA=$(echo "$LAST" | grep -oP 'ETA=\K[0-9.]+')
fi

# Convert /s to kH/s for HiveOS
khs=$(echo "scale=3; ${RATE:-0} / 1000" | bc 2>/dev/null || echo "0")

# Get GPU temps and fan from nvidia-smi (HiveOS has this)
GPU_COUNT=0
TEMPS="[]"
FANS="[]"
if command -v nvidia-smi &>/dev/null; then
    TEMP_LIST=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null | tr '\n' ',')
    FAN_LIST=$(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null | tr '\n' ',')
    GPU_COUNT=$(nvidia-smi --list-gpus 2>/dev/null | wc -l)
    # Convert to JSON arrays
    TEMPS=$(echo "[$TEMP_LIST]" | sed 's/,\]/]/')
    FANS=$(echo "[$FAN_LIST]" | sed 's/,\]/]/' | sed 's/ //g')
fi

# Uptime from log file age
UPTIME=0
if [[ -f "$LOG" ]]; then
    LOG_MTIME=$(stat -c %Y "$LOG" 2>/dev/null || echo 0)
    NOW=$(date +%s)
    UPTIME=$((NOW - LOG_MTIME + 1))
fi

# Build stats JSON
stats=$(cat <<EOF
{
  "hs": [$RATE],
  "hs_units": "hs",
  "temp": $TEMPS,
  "fan": $FANS,
  "uptime": $UPTIME,
  "ver": "1.0",
  "ar": [0, 0],
  "algo": "mwc-bip39",
  "mwc_progress": "$PROGRESS%",
  "mwc_seed": "$SEED",
  "mwc_eta": "${ETA}h"
}
EOF
)
