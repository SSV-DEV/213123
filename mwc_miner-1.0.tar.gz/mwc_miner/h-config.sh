#!/usr/bin/env bash

# h-config.sh — generates mwc_miner.conf from HiveOS flight sheet variables
# Called every time the miner starts.
# $CUSTOM_USER_CONFIG holds anything typed in the "Extra config" field.

mkdir -p /var/log/miner/mwc_miner

# Defaults
BATCH_SIZE="${BATCH_SIZE:-1000000}"
INSTANCES="${INSTANCES:-1}"
OFFSET="${OFFSET:-0}"

# Parse extra config lines from flight sheet (KEY=VALUE format)
if [[ -n "$CUSTOM_USER_CONFIG" ]]; then
    while IFS='=' read -r key val; do
        key=$(echo "$key" | tr -d ' ')
        val=$(echo "$val" | tr -d ' ')
        case "$key" in
            batch-size|BATCH_SIZE) BATCH_SIZE="$val" ;;
            instances|INSTANCES)   INSTANCES="$val" ;;
            offset|OFFSET)         OFFSET="$val" ;;
            resume|RESUME)         RESUME="$val" ;;
        ADDRESSES)             ADDRESSES="$val" ;;  # space or newline separated bc1q... addresses
    done <<< "$CUSTOM_USER_CONFIG"
fi

# Write config file
cat > "$CUSTOM_CONFIG_FILENAME" <<EOF
BATCH_SIZE=$BATCH_SIZE
INSTANCES=$INSTANCES
OFFSET=$OFFSET
${RESUME:+RESUME=$RESUME}
${ADDRESSES:+ADDRESSES="$ADDRESSES"}
EOF

echo "mwc_miner config written: batch=$BATCH_SIZE instances=$INSTANCES offset=$OFFSET"
