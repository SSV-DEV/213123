#!/usr/bin/env bash
# h-run.sh — starts gpu_mwc_hashcat.js with bundled portable hashcat

DIR="$(cd "$(dirname "$0")" && pwd)"
CONF="$CUSTOM_CONFIG_FILENAME"
LOG="/var/log/miner/mwc_miner/mwc_miner.log"
TARGETS_FILE="$DIR/addresses.txt"

mkdir -p /var/log/miner/mwc_miner

# Read config
[[ -f "$CONF" ]] && source "$CONF"

# ── Point to the bundled hashcat binary ───────────────────────────────────────
# install.sh downloads hashcat into $DIR/hashcat/hashcat.bin
# This means OpenCL/ kernels are at $DIR/hashcat/OpenCL/ — co-located ✓
HASHCAT_BIN="$DIR/hashcat/hashcat.bin"
if [[ -x "$HASHCAT_BIN" ]]; then
    export HASHCAT_PATH="$HASHCAT_BIN"
    echo "hashcat: $HASHCAT_BIN"
else
    # Fallback: system hashcat (if user installed it separately)
    SYS_HC=$(command -v hashcat 2>/dev/null || echo "")
    if [[ -n "$SYS_HC" ]]; then
        export HASHCAT_PATH="$SYS_HC"
        echo "hashcat (system): $SYS_HC"
    else
        echo "ERROR: hashcat not found. Run install.sh first."
        echo "  bash $DIR/install.sh"
        exit 1
    fi
fi

# ── Write addresses.txt ───────────────────────────────────────────────────────
{
    echo "bc1qyjwa0tf0en4x09magpuwmt2smpsrlaxwn85lh6"
    [[ -n "$ADDRESSES" ]] && echo "$ADDRESSES" | tr ' ' '\n'
} > "$TARGETS_FILE"

echo "Targets:"
cat "$TARGETS_FILE"

# ── Build args ────────────────────────────────────────────────────────────────
ARGS="--targets=$TARGETS_FILE"
[[ -n "$BATCH_SIZE" ]] && ARGS="$ARGS --batch-size=$BATCH_SIZE"
[[ -n "$INSTANCES" ]]  && ARGS="$ARGS --instances=$INSTANCES"
[[ -n "$OFFSET" ]]     && ARGS="$ARGS --offset=$OFFSET"
[[ -n "$RESUME" ]]     && ARGS="$ARGS --resume=$RESUME"

echo "Starting: node gpu_mwc_hashcat.js $ARGS"

NODE=$(command -v node || command -v nodejs || echo "/usr/local/bin/node")
exec "$NODE" "$DIR/gpu_mwc_hashcat.js" $ARGS 2>&1 | tee "$LOG"
