#!/usr/bin/env bash
# install.sh — runs once after the package is extracted on HiveOS
# Downloads hashcat portable binary and Node.js if needed.
# No apt dependencies required — everything self-contained.

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=== mwc_miner install === (dir: $DIR)"

# ── 1. Node.js ────────────────────────────────────────────────────────────────
NODE=$(command -v node || command -v nodejs || echo "")
if [[ -z "$NODE" ]]; then
    echo "Installing Node.js..."
    apt-get update -qq && apt-get install -y -qq nodejs 2>/dev/null || true
    NODE=$(command -v node || command -v nodejs || echo "")
fi
if [[ -z "$NODE" ]]; then
    echo "ERROR: Node.js not found. Try: apt install nodejs"
    exit 1
fi
echo "Node.js: $("$NODE" --version)"

# ── 2. hashcat portable binary ────────────────────────────────────────────────
HASHCAT_DIR="$DIR/hashcat"
HASHCAT_BIN="$HASHCAT_DIR/hashcat.bin"

if [[ -x "$HASHCAT_BIN" ]]; then
    echo "hashcat already installed: $HASHCAT_BIN"
else
    echo "Downloading hashcat portable binary..."

    # Need 7z to extract the .7z release package
    if ! command -v 7z &>/dev/null && ! command -v 7za &>/dev/null; then
        echo "Installing p7zip..."
        apt-get install -y -qq p7zip-full 2>/dev/null || true
    fi
    SEVENZIP=$(command -v 7z || command -v 7za || echo "")

    HASHCAT_VER="6.2.6"
    HASHCAT_URL="https://hashcat.net/files/hashcat-${HASHCAT_VER}.7z"
    HASHCAT_TMP="/tmp/hashcat-${HASHCAT_VER}.7z"

    echo "Downloading $HASHCAT_URL ..."
    wget -q --show-progress -O "$HASHCAT_TMP" "$HASHCAT_URL" || \
        curl -L -o "$HASHCAT_TMP" "$HASHCAT_URL"

    echo "Extracting..."
    mkdir -p "$HASHCAT_DIR"
    if [[ -n "$SEVENZIP" ]]; then
        "$SEVENZIP" x "$HASHCAT_TMP" -o"$HASHCAT_DIR" -y > /dev/null
        # hashcat extracts into a versioned subdir — flatten it
        INNER=$(find "$HASHCAT_DIR" -name "hashcat.bin" -o -name "hashcat" | head -1)
        if [[ -n "$INNER" ]]; then
            INNER_DIR=$(dirname "$INNER")
            if [[ "$INNER_DIR" != "$HASHCAT_DIR" ]]; then
                cp -r "$INNER_DIR/"* "$HASHCAT_DIR/"
            fi
        fi
    else
        echo "ERROR: 7z not available and could not install p7zip-full."
        echo "Manually install hashcat to $HASHCAT_DIR and set HASHCAT_PATH."
        exit 1
    fi

    rm -f "$HASHCAT_TMP"
    chmod +x "$HASHCAT_BIN" 2>/dev/null || true

    # Test it
    if [[ -x "$HASHCAT_BIN" ]]; then
        echo "hashcat OK: $("$HASHCAT_BIN" --version 2>&1 | head -1)"
    else
        echo "WARNING: hashcat.bin not found after extraction."
        echo "Check $HASHCAT_DIR manually."
    fi
fi

# ── 3. Permissions ────────────────────────────────────────────────────────────
chmod +x "$DIR/h-run.sh" "$DIR/h-config.sh" "$DIR/h-stats.sh" 2>/dev/null || true
mkdir -p /var/log/miner/mwc_miner

echo "=== mwc_miner ready ==="
echo "hashcat: $HASHCAT_BIN"
echo "Run: node $DIR/gpu_mwc_hashcat.js"
